<footer class="main-footer">
	
	

	Sistema Gestión de Ventas para MDG - UPDS.


</footer>